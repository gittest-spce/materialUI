export class SET{
    Term: any;
    Days: any;
    
}