import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trsdialog',
  templateUrl: './trsdialog.component.html',
  styleUrls: ['./trsdialog.component.scss']
})
export class TrsdialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
