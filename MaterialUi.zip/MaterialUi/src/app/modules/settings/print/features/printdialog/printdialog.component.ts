import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-printdialog',
  templateUrl: './printdialog.component.html',
  styleUrls: ['./printdialog.component.scss']
})
export class PrintdialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
