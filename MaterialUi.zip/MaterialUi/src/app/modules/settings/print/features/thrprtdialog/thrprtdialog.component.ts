import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thrprtdialog',
  templateUrl: './thrprtdialog.component.html',
  styleUrls: ['./thrprtdialog.component.scss']
})
export class ThrprtdialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
